package de.mannheim.sos.tunnelSAS.planner;

public class PlanData2 {

	private String plan = "22222222222222";

	public PlanData2() {
	}
	
	public String toString() {
		return plan;
	}
}
