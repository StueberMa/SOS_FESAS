package de.mannheim.sos.tunnelSAS.planner;

public class PlanData {

	private String plan = "12345678987654321";

	public PlanData() {
	}
	
	public String toString() {
		return plan;
	}
}
