package de.mannheim.wifo2.dummyanalyzer;

import de.mannheim.wifo2.fesas.logicRepositoryStructure.data.metadata.logic.LogicType;
import de.mannheim.wifo2.fesas.logicRepositoryStructure.data.metadata.logic.logicInterfaces.IAnalyzerLogic;
import de.mannheim.wifo2.fesas.sasStructure.adaptationLogic.IAdaptationLogic;
import de.mannheim.wifo2.fesas.sasStructure.data.adaptationLogic.information.IInformationType;

public class AnalyzerLogicDummy_3VarLargerX extends AnalyzerLogicDummy implements IAnalyzerLogic {
	
	public AnalyzerLogicDummy_3VarLargerX() {
		// needed for Logic Loading mechanism
		super();
		threshold = 5;
		expectedValues = 2;
		this.informationType = InformationType.Analyzing_SIMPLESAS;
	}
	
	public AnalyzerLogicDummy_3VarLargerX(IAdaptationLogic adaptationLogic, IInformationType informationType) {
		super(adaptationLogic,informationType);
		threshold = 5;
		expectedValues = 3;
		this.informationType = InformationType.Analyzing_SIMPLESAS;
		
	}

	private static final LogicType type = LogicType.ANALYZER;
	private static final String id = "AnalyzerLogicDummy_3VarLargerX";
	
	@Override
	public LogicType getLogicType() {
		return type;
	}

	@Override
	public String getID() {
		return id;
	}
	
}
