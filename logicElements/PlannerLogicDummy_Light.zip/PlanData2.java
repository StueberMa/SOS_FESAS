package de.mannheim.wifo2.dummyplanner;

public class PlanData2 {

	private String plan = "22222222222222";

	public PlanData2() {
	}
	
	public String toString() {
		return plan;
	}
}
