package de.mannheim.wifo2.dummyplanner;

public class PlanData {

	private String plan = "12345678987654321";

	public PlanData() {
	}
	
	public String toString() {
		return plan;
	}
}
